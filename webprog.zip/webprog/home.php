<?php 
	print '
	<h1>H&M</h1>
	<figure>
		<img src="img/HM_Article.jpg" alt="H&M" title="H&M">
		<figcaption>The boutique offers yoga classes and a cafe with a garden as the Swedish budget chain seeks to revive flagging sales.</figcaption>
	</figure>
	<p>BERLIN, Germany — H&M opened a boutique-like store in a trendy neighbourhood in Berlin on Friday that offers yoga classes, a cafe with a garden and space for other brands as the Swedish budget chain seeks a new look to revive flagging sales.</p>
        <p>H&M first piloted the idea of a smaller, more upmarket store in its home town of Stockholm last year and is now bringing the concept to its biggest market of Germany, where it runs 462 of its 4,972 stores worldwide.</p>
        <p>The move comes as H&M invests heavily and tries new concepts after years of falling profits and growing inventories due to slowing sales at its core budget stores, recently posting its first rise in quarterly pretax profit in more than two years.</p>
        <p>The Berlin store is about a fifth of the size of regular H&M stores and features clothes selected to appeal to local tastes, as well as perfumes, "vegan" cosmetics, handbags and second-hand garments from partner brands.</p>
        <p>"We need stores closer to where people hang out. We are not used to operating in smaller spaces," said Anna Bergare, head of business development at the H&M Lab, which is testing new concepts and technology.</p>
        <p>The new store stocks a limited range of mostly casual womenswear, but also features a few men jackets and T-shirts and yoga gear aimed at customers attending classes in the store.</p>
        <p>Source: <a href="https://www.businessoffashion.com/articles/news-analysis/hm-opens-experiential-boutique-like-store-in-germany" target="_blank">The Business of Fashion</a></p>
	<p>
            Social media:<br>
            <a href="https://www.linkedin.com/company/h&m" target="_blank"><img src="img/linkedin.svg" alt="Linkedin" title="Linkedin" style="width:24px; margin-top:0.4em"></a>
            <a href="https://twitter.com/hm" target="_blank"><img src="img/twitter.svg" alt="Twitter" title="Twitter" style="width:24px; margin-top:0.4em"></a>
            <a href="https://plus.google.com/113372414904624897851" target="_blank"><img src="img/google+.svg" alt="Google+" title="Google+" style="width:24px; margin-top:0.4em"></a>
        </p>';
?>