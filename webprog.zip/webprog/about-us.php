<?php 
	print '
	<h1>About Us</h1>
		<h2>The Business of Fashion</h2>
		<video width="25%" controls poster="" >
		  <source src="video/maska.mp4" type="video/mp4">
		  Your browser does not support HTML5 video.
		</video>
        <p>Few readers will recognize the woman on the cover of Business of Fashions print edition this month. She is not a model, she is not a designer, she is not the leader of a luxury conglomerate. Kalpona Akter is a former child worker from Bangladesh.</p>
        <p>Akter, now an activist fighting for what she calls "jobs with dignity," began working in a garment factory aged 12 after her father (the familys sole earner) suffered a stroke. She remembers her first day vividly -- the sound of the machines & shouting voices were frightening. On a video call from Dhaka, she recounted having "never seen so many people in one place before."</p>
        <p>Fast-forward a couple of years & her fear had evolved into activism. By the age of 14, she was campaigning on the factory floor. By 17, it was her bosses who were the fearful ones. They fired her "for being a troublemaker and tried to get other factories to blacklist her. This move proved to be short-sighted -- on their part, at least -- as it only served to propel Akter into a far more powerful position. The 42-year-old is now the executive director of the Bangladesh Center for Worker Solidarity.</p>
        <p>By her own estimate, she represents some four million people at the bottom of the fashion supply chain -- many of them whom labor in conditions that would shock those working in the industry in New York, London, Paris or Milan.</p>
        <p>Minimum wage for garment factory workers in Bangladesh is currently around $68 per month. She is campaigning to get this up to $200 by the end of the year, while simultaneously battling issues around economic freedom for women, violence and mistreatment on the factory floor.</p>
		<p>Video courtesy of <a href="https://www.youtube.com/watch?v=I1AqjvdiubA" target="_blank">youtube.com</a></p>';
?>